<div class="footer">
	<!---footer>&copy; Rafika</br--->

  <!--p>phone no:01842241910</p-->
  <!--p>E-mail: <a href="mailto:rafika35-1050@diiu.edu.bd">rafika35-1050@diiu.edu.bd</a>.</p-->

	 </footer>
</div>