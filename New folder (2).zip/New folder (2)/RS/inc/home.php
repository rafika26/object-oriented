<?php include 'config.php';	?>
<?php include 'Database.php';?>
<?php $db=new Database(); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="content clear">
	<div class="menubar clear">
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="contact.php">Contact</a></li>
			<li><a href="about.php">About</a></li>
			<li><a href="Record_Info.php">Record Info</a></li>
			
			<li><a href="Register.php">Register</a></li>
			<li><a href="Login.php">Log in</a></li>
			<li><a href="logout.php"class="logout">Log out</a></li>
		</ul>
	</div>