<?php include "inc/head.php" ?>
<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>User Login</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1"> 
        <link rel="stylesheet" href="style.css">
    </head>
<body>

    <section class="loginpage clear">
    <?php
    if ($_SERVER['REQUEST_METHOD']=='POST') {
        $username=$_POST['username'];
        $password=$_POST['password'];

        $username=mysqli_real_escape_string($db->link,$username);
        $password=mysqli_real_escape_string($db->link,$password);
        if (empty($username) || empty($password)) {
          echo "<span class='error';>Enter user name or password</span>";
        }
        else{
        $query="SELECT * FROM tbl_user WHERE name='$username' AND pass='$password'";
        $result=$db->select($query);
        if ($result!=false) {
            $value=$result->fetch_assoc();

           header("Location:index.php");
        }
        else
        {
        echo "<span style='color:red;font-size:18px;'> Username or password not matched !</span>";
        }
    }
}
?>
<div class="logincontent"></div>

    <form action="" method="post" class="login">
            <h2>User Login</h2>
        <table>
                <tr>
                <td><input type="text" name="username" placeholder="Username"></td>
            </tr>
             <tr>
                <td><input type="password" name="password" placeholder="Password"></td>
            </tr>
                <td><input type="submit" name="submit" value="submit"></td>
            </tr>
        </table>
    </form>
</section>
<?php include "inc/footer.php" ?>
</body>
</html>
