<?php include 'config.php';	?>
<?php include 'Database.php';?>
<?php $db=new Database(); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>