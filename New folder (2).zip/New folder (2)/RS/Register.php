<?php include "inc/home.php" ?>
<div class="register clear">

<form action="" method="post">
    <table class="form">
        <tr>
            <td><label>Username</label></td>
            <td><input type="text" name="name" placeholder="Enter a Name ..."></td>
        </tr>
        <tr>
            <td><label>Password</label></td>
            <td><input type="password" name="pass" placeholder="Enter a Password ..."></td>
        </tr>
        <tr>
            <td><label>Email</label></td>
            <td><input type="email" name="emial" placeholder="Enter a Vaid Email ..."></td>
        </tr>
        <tr>
            <td><label>Phone Number</label></td>
			<td><input type="text" name="phone" placeholder="Enter a Phone number ..."></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="submit" value="Register"></td>
        </tr>
    </table>
</form>
<?php
if ($_SERVER['REQUEST_METHOD']=='POST') {
    $name 	= $_POST['name'];
    $pass 	= $_POST['pass'];
    $emial  = $_POST['emial'];
    $phone  = $_POST['phone'];
    
    if (empty($name) || empty($pass) || empty($emial)|| empty($phone) ) {
        echo "<span class='error'>Field must not be empty !.</span>";
    }
    else
    {
        $query="INSERT INTO tbl_user(name,pass,emial,phone) VALUES ('$name','$pass',' $emial','$phone')";
        $catinsert=$db->insert($query);
        if ($catinsert) {
            echo "<span class='success'>User Create Successfully</span>";
            header("index.php");
        }
        else{
          echo "<span class='error'>User Not Create !</span>";  
        }
    }

}
?>
</div>
<?php include "inc/footer.php" ?>
</body>
</html>