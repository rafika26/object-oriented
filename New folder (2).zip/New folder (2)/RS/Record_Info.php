<?php include "inc/home.php" ?>
<div class="record clear">

<form action="" method="post">
    <table class="form">
	    <tr>
            <td><label>Record Information</label></td>
            <!---td><input type="text" name="fname" placeholder="Enter a Name ..."></td--->
        </tr>
        <tr>
            <td><label>Fristname</label></td>
            <td><input type="text" name="fname" placeholder="Enter a Name ..."></td>
        </tr>
		<tr>
            <td><label>Lastname</label></td>
            <td><input type="text" name="lname" placeholder="Enter a Name ..."></td>
        </tr>
        <tr>
            <td><label>Address</label></td>
            <td><input type="text" name="address" placeholder="Enter a Password ..."></td>
        </tr>
		<tr>
            <td><label>City</label></td>
            <td><input type="text" name="city" placeholder="Enter a Name ..."></td>
        </tr>
        <tr>
            <td><label>State</label></td>
            <td><input type="text" name="state" placeholder="Enter a Vaid Email ..."></td>
        </tr>
        <tr>
            <td><label>Phone Number</label></td>
			<td><input type="text" name="phone" placeholder="Enter a Phone number ..."></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="submit" value="Submit"></td>
        </tr>
    </table>
</form>
<?php
if ($_SERVER['REQUEST_METHOD']=='POST') {
    $fname 	= $_POST['fname'];
	$lname 	= $_POST['lname'];
    $address = $_POST['address'];
    $city  = $_POST['city'];
	$state 	= $_POST['state'];
    $phone  = $_POST['phone'];
    
    if (empty($fname) || empty($lname)||empty($address)||empty($city) || empty($state)|| empty($phone) ) {
        echo "<span class='error'>Field must not be empty !.</span>";
    }
    else
    {
        $query="INSERT INTO tbl_user(fname,lname,address,city,state,phone) VALUES ('$fname','$lname ',' $address','$city','$state','$phone')";
        $catinsert=$db->insert($query);
        if ($catinsert) {
            echo "<span class='success'> Create Successfully</span>";
            header("index.php");
        }
        else{
          echo "<span class='error'> Not Create !</span>";  
        }
    }

}
?>
</div>
<?php include "inc/footer.php" ?>
</body>
</html>